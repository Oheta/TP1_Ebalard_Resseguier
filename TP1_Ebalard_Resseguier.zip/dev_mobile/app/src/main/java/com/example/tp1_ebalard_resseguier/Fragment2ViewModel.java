package com.example.tp1_ebalard_resseguier;

import androidx.lifecycle.ViewModel;

public class Fragment2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
