package com.example.tp1_ebalard_resseguier;

import androidx.lifecycle.ViewModel;

public class Fragment1ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
